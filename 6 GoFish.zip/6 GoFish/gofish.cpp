#include <iostream>
//#include <cstdlib>
//#include <ctime>
//#include <vector>

#include "card.h"
#include "deck.h"

int main() {

/*// Testing the Card class
  Card c1 = Card();
  cout << c1 << endl;

  Card c2 = Card(4,Card::spades);
  cout << c2 << endl;
  cout << c2.getSuit() << endl;
  cout << c2.getRank() << endl;
  cout << c2.suitString(c2.getSuit()) << endl;

  Card c3 = Card(10,Card::spades);
  cout << c3.toString() << endl;

  Card c4 = Card(11,Card::clubs);
  cout << c4.rankString(c4.getRank()) << endl;

  Card c5 = Card(12,Card::diamonds);
  Card c6 = Card(13,Card::hearts);
  Card c7 = Card(10,Card::diamonds);
  cout << c5.sameSuitAs(c7) << endl;
  cout << c5.sameSuitAs(c6) << endl;

  Card c8 = Card(14,Card::diamonds);
  cout << c8.toString() << endl;
  Card c9 = Card(10,Card::spades);
  cout << (c3 == c9) << endl;
  cout << (c3 == c7) << endl;
  cout << (c3 != c9) << endl;
  cout << (c3 != c7) << endl;*/

/*// Testing the Deck class
  Deck d1 = Deck();
  cout << d1.toString() << endl;
  d1.shuffle();
  cout << d1.toString() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.toString() << endl;
  cout << d1.size() << endl;*/

  return 0;
}