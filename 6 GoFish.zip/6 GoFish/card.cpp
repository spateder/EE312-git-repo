// Created by Saagar Pateder on 4/9/2019.
// File Name: card.cpp
// Original template written by Owen Astrachan and Roger Priebe
// This class represents a playing card, i.e., "ace of spades"
// A Card is constructed from a rank (int in range 1-13)
// and a suit (Card::spades, Card::hearts, Card::diamonds, Card::clubs)
//
// Cards should be created by a Deck (see deck.h), a Deck returns good cards
// The function toString() converts a card to a string for printing purposes
//
// Accessor functions include
// int GetRank()       -- returns 1, 2, ..., 13 for ace, two, ..., king
// bool SameSuitAs(c)  -- returns true if same suit as Card c
// string suitString() -- returns "s", "h", "d" or "c"
// Note that the Ace is represented by 1 and the King by 13

#include "card.h"
#include <iostream>
#include <string>

using namespace std;

// default constructor creates the Ace of Spades
Card::Card() {
  myRank = 1;
  mySuit = spades;
}

Card::Card(int rank, Suit s) {
  myRank = rank;
  mySuit = s;
}

int Card::getRank() const {
  return myRank;
}

Card::Suit Card::getSuit() const {
  return mySuit;
}

string Card::suitString(Card::Suit s) const {
  if (s == spades) {return "s";}
  else if (s == clubs) {return "c";}
  else if (s == diamonds) {return "d";}
  else if (s == hearts) {return "h";}
  else {return "X";} // "X" indicates an error
}

// return string version e.g. Ac 4h Js
string Card::toString() const {
  return rankString(myRank) + suitString(mySuit);
}

string Card::rankString(int r) const {
  if (r == 1) {return "A";}
  else if (r == 2) {return "2";}
  else if (r == 3) {return "3";}
  else if (r == 4) {return "4";}
  else if (r == 5) {return "5";}
  else if (r == 6) {return "6";}
  else if (r == 7) {return "7";}
  else if (r == 8) {return "8";}
  else if (r == 9) {return "9";}
  else if (r == 10) {return "T";}
  else if (r == 11) {return "J";}
  else if (r == 12) {return "Q";}
  else if (r == 13) {return "K";}
  else {return "X";} // "X" indicates an error
}

bool Card::sameSuitAs(const Card& c) const {
  return (mySuit == c.getSuit());
}

bool Card::operator ==(const Card& rhs) const {
  return ((mySuit == rhs.mySuit) && ((myRank == rhs.myRank)));
}

bool Card::operator !=(const Card& rhs) const {
  return !((mySuit == rhs.mySuit) && ((myRank == rhs.myRank)));
}

ostream& operator << (ostream& out, const Card& c) {
  out << c.toString();
  return out;
}