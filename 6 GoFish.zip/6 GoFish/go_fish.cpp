#include <iostream>
//#include <cstdlib>
//#include <vector>

#include "card.h"
#include "deck.h"
#include "player.h"

int main() {

/*// Testing the Card class
  Card c1 = Card();
  cout << c1 << endl;

  Card c2 = Card(4,Card::spades);
  cout << c2 << endl;
  cout << c2.getSuit() << endl;
  cout << c2.getRank() << endl;
  cout << c2.suitString(c2.getSuit()) << endl;

  Card c3 = Card(10,Card::spades);
  cout << c3.toString() << endl;

  Card c4 = Card(11,Card::clubs);
  cout << c4.rankString(c4.getRank()) << endl;

  Card c5 = Card(12,Card::diamonds);
  Card c6 = Card(13,Card::hearts);
  Card c7 = Card(10,Card::diamonds);
  cout << c5.sameSuitAs(c7) << endl;
  cout << c5.sameSuitAs(c6) << endl;

  Card c8 = Card(14,Card::diamonds);
  cout << c8.toString() << endl;
  Card c9 = Card(10,Card::spades);
  cout << (c3 == c9) << endl;
  cout << (c3 == c7) << endl;
  cout << (c3 != c9) << endl;
  cout << (c3 != c7) << endl;*/

/*// Testing the Deck class
  Deck d1 = Deck();
  d1.print();
  d1.shuffle();
  d1.print();
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  d1.print();
  cout << d1.size() << endl;
  d1.shuffle();
  d1.print();*/

/*// Testing the Player class
  Player p1 = Player();
  cout << p1.getName() << endl;
  p1.setName("Matilda");
  cout << p1.getName() << endl;
  Player p2 = Player("Bevo");
  cout << p2.getName() << endl;

  Deck d1 = Deck();
  d1.shuffle();
  d1.print();

  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();

  for (int i = 0; i < 8; i++) {p1.addCard(d1.dealCard());} // Deal 8 cards to p1
  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();

  Card c1; Card c2;
  cout << p1.checkHandForBook(c1, c2);
  cout << "Card c1:" << c1 << "\nCard c2:" << c2 << endl;

  while (p1.checkHandForBook(c1, c2)) {
    p1.bookCards(c1, c2);
  }
  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();
  cout << "p1 Book Size " << p1.getBookSize() << endl;
  cout << "p1ShowBook() \n" << p1.showBooks();

  Card c3 = Card();
  cout << "p1.rankinHand " << p1.rankInHand(c3) << endl;

  for (int i = 0; i < 5; i++) {p1.addCard(d1.dealCard());} // Deal 5 cards to p1
  cout << "p1ShowHand() \n" << p1.showHand();
  cout << "p1.CardinHand " << p1.cardInHand(c3) << endl;
  cout << p1.chooseCardFromHand() << endl;*/

  return 0;
}