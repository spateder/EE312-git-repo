#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "card.h"
#include "deck.h"
#include "player.h"

int main() {

/*// Testing the Card class
  Card c1 = Card();
  cout << c1 << endl;

  Card c2 = Card(4,Card::spades);
  cout << c2 << endl;
  cout << c2.getSuit() << endl;
  cout << c2.getRank() << endl;
  cout << c2.suitString(c2.getSuit()) << endl;

  Card c3 = Card(10,Card::spades);
  cout << c3.toString() << endl;

  Card c4 = Card(11,Card::clubs);
  cout << c4.rankString(c4.getRank()) << endl;

  Card c5 = Card(12,Card::diamonds);
  Card c6 = Card(13,Card::hearts);
  Card c7 = Card(10,Card::diamonds);
  cout << c5.sameSuitAs(c7) << endl;
  cout << c5.sameSuitAs(c6) << endl;

  Card c8 = Card(14,Card::diamonds);
  cout << c8.toString() << endl;
  Card c9 = Card(10,Card::spades);
  cout << (c3 == c9) << endl;
  cout << (c3 == c7) << endl;
  cout << (c3 != c9) << endl;
  cout << (c3 != c7) << endl;*/

/*// Testing the Deck class
  Deck d1 = Deck();
  d1.print();
  d1.shuffle();
  d1.print();
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  cout << d1.dealCard() << endl;
  d1.print();
  cout << d1.size() << endl;
  d1.shuffle();
  d1.print();*/

/*// Testing the Player class
  Player p1 = Player();
  cout << p1.getName() << endl;
  p1.setName("Matilda");
  cout << p1.getName() << endl;
  Player p2 = Player("Bevo");
  cout << p2.getName() << endl;

  Deck d1 = Deck();
  d1.shuffle();
  d1.print();

  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();

  for (int i = 0; i < 3; i++) {p1.addCard(d1.dealCard());} // Deal 3 cards to p1
  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();

  Card c1; Card c2;
  cout << p1.checkHandForBook(c1, c2);
  cout << "Card c1:" << c1 << "\nCard c2:" << c2 << endl;

  while (p1.checkHandForBook(c1, c2)) {
    p1.bookCards(c1, c2);
  }
  cout << "p1 Hand Size " << p1.getHandSize() << endl;
  cout << "p1ShowHand() \n" << p1.showHand();
  cout << "p1 Book Size " << p1.getBookSize() << endl;
  cout << "p1ShowBook() \n" << p1.showBooks();

  Card c3 = Card();
  cout << "p1.rankinHand " << p1.rankInHand(c3) << endl;

  for (int i = 0; i < 2; i++) {p1.addCard(d1.dealCard());} // Deal 5 cards to p1
  cout << "p1ShowHand() \n" << p1.showHand();
  cout << "p1.CardinHand " << p1.cardInHand(c3) << endl;
  cout << p1.chooseCardFromHand() << endl;*/

  // Go Fish Game

  // Initialize file to be written to
  ofstream log("gofish_results.txt");
  if(!log.is_open()) {
    cout << "ERROR: unable to open file!" << endl;
    exit(-1);
  }

  // Initialize the deck, players, and card holders
  Deck d = Deck();
  d.shuffle();
  Player p1 = Player("Borat");
  Player p2 = Player("Aladdin");
  Card c1; Card c2; Card c3;
  bool p1turn; bool p2turn;
  int round = 1;

  log << "Hello, my name eh " << p1.getName() << endl;
  log << "Hello, my name eh " << p2.getName() << "\n" << endl;
  log << "LET THE GAMES BEGIN!" << endl;

  // Deal 7 cards to both players
  for (int i = 0; i < 7; i++) {
    p1.addCard(d.dealCard());
    p2.addCard(d.dealCard());
  }

  log << "Player 1's Hand:" << endl;
  log << p1.showHand() << endl;
  log << "Player 2's Hand:" << endl;
  log << p2.showHand() << endl << endl;

  // Book the initial pairs
  while (p1.checkHandForBook(c1, c2)) {
    log << "Player 1 books " << c1 << " " << c2 << endl;
    p1.bookCards(c1, c2);
  }
  while (p2.checkHandForBook(c1, c2)) {
    log << "Player 2 books " << c1 << " " << c2 << endl;
    p2.bookCards(c1, c2);
  }

  log << "Player 1's Hand:" << endl;
  log << p1.showHand() << endl;
  log << "Player 2's Hand:" << endl;
  log << p2.showHand() << endl;
  log << "Player 1's Book:" << endl;
  log << p1.showBooks() << endl;
  log << "Player 2's Book:" << endl;
  log << p2.showBooks() << endl;

  while ((p1.getBookSize() + p2.getBookSize()) < 52) {

    log << "ROUND " << round << endl;

    // Player 1's turn
    p1turn = true;

    // if Player 1 has no cards in hand, then deal him/her a card from the deck (if any are left)
    if ((p1.getHandSize() == 0) && (d.size() != 0)) {
      log << "Player 1 draws " << d.showNextCard() << endl;
      p1.addCard(d.dealCard());
      p1turn = false;
    }

    while (p1turn) {

      log << "\nIt's Player 1's turn." << endl;
      log << "Player 1's Hand:" << endl;
      log << p1.showHand() << endl;
      log << "Player 2's Hand:" << endl;
      log << p2.showHand() << endl;

      c3 = p1.chooseCardFromHand(); // select a card from the hand
      log << "Player 1: Do you have any " << c3.getRank() << "'s?" << endl;

      // if p2 has the card
      if (p2.rankInHand(c3)) {
        log << "Player 2: Yes!" << endl;
        Card temp = p2.scanForRank(c3.getRank()); // use scanForRank() to identify which card p2 has
        log << "Player 2 gave Player 1 the card " << temp << "." << endl;
        p1.addCard(p2.removeCardFromHand(temp)); // move the card from p2's Hand to p1's Hand
        // have p1 book all pairs
        while (p1.checkHandForBook(c1, c2)) {
          log << "Player 1 books " << c1 << " " << c2 << endl;
          p1.bookCards(c1, c2);
          log << "Player 1's Hand:" << endl;
          log << p1.showHand() << endl;
          log << "Player 2's Hand:" << endl;
          log << p2.showHand() << endl;
          log << "Player 1's Book:" << endl;
          log << p1.showBooks() << endl;
          log << "Player 2's Book:" << endl;
          log << p2.showBooks() << endl;
        }
        // Then p1 gets to ask again, unless he/she has no more cards left in his hand
        if (p1.getHandSize() == 0) {
          p1turn = false;
        }
      }

      // if p2 doesn't have a card
      else {
        log << "Player 2: Go Fish!" << endl;
        p1turn = false;
      }

      // deal a card, if it isn't going to be p1's turn again, and if there are cards left in the deck
      if ((d.size() != 0) && (!p1turn)) {
        log << "Player 1 draws " << d.showNextCard() << endl;
        p1.addCard(d.dealCard());
      }

      // have p1 book all pairs
      while (p1.checkHandForBook(c1, c2)) {
        log << "Player 1 books " << c1 << " " << c2 << endl;
        p1.bookCards(c1, c2);
      }

    }

    // check if the game is over
    if ((p1.getBookSize() + p2.getBookSize()) == 52) {break;}

    // Player 2's turn
    p2turn = true;

    // if Player 2 has no cards in hand, then deal him/her a card from the deck (if any are left)
    if ((p2.getHandSize() == 0) && (d.size() != 0)) {
      log << "Player 1 draws " << d.showNextCard() << endl;
      p2.addCard(d.dealCard());
      p2turn = false;
    }

    while (p2turn) {

      log << "\nIt's Player 2's turn." << endl;
      log << "Player 1's Hand:" << endl;
      log << p1.showHand() << endl;
      log << "Player 2's Hand:" << endl;
      log << p2.showHand() << endl;

      c3 = p2.chooseCardFromHand(); // select a card from the hand
      log << "Player 2: Do you have any " << c3.getRank() << "'s?" << endl;

      // if p1 has a card
      if (p1.rankInHand(c3)) {
        log << "Player 1: Yes!" << endl;
        Card temp = p1.scanForRank(c3.getRank()); // use scanForRank() to identify which card p1 has
        log << "Player 1 gave Player 2 the card " << temp << "." << endl;
        p2.addCard(p1.removeCardFromHand(temp)); // move the card from p1's Hand to p2's Hand
        // have p2 book all pairs
        while (p2.checkHandForBook(c1, c2)) {
          log << "Player 2 books " << c1 << " " << c2 << endl;
          p2.bookCards(c1, c2);
          log << "Player 1's Hand:" << endl;
          log << p1.showHand() << endl;
          log << "Player 2's Hand:" << endl;
          log << p2.showHand() << endl;
          log << "Player 1's Book:" << endl;
          log << p1.showBooks() << endl;
          log << "Player 2's Book:" << endl;
          log << p2.showBooks() << endl;
        }
        // Then p2 gets to ask again, unless he/she has no more cards left in his hand
        if (p2.getHandSize() == 0) {
          p2turn = false;
        }
      }

        // if p1 doesn't have a card
      else {
        log << "Player 1: Go Fish!" << endl;
        p2turn = false;
      }

      // deal a card, if it isn't going to be p2's turn again, and if there are cards left in the deck
      if ((d.size() != 0) && (!p2turn)) {
        log << "Player 1 draws " << d.showNextCard() << endl;
        p2.addCard(d.dealCard());
      }

      // have p2 book all pairs
      while (p2.checkHandForBook(c1, c2)) {
        log << "Player 2 books " << c1 << " " << c2 << endl;
        p2.bookCards(c1, c2);
        log << "Player 1's Hand:" << endl;
        log << p1.showHand() << endl;
        log << "Player 2's Hand:" << endl;
        log << p2.showHand() << endl;
        log << "Player 1's Book:" << endl;
        log << p1.showBooks() << endl;
        log << "Player 2's Book:" << endl;
        log << p2.showBooks() << endl;
      }

    }

    round++;

  }

  // Game over
  log << "GAME OVER" << endl;
  log << "Player 1 booked " << p1.getBookSize() << " cards." << endl;
  log << "Player 2 booked " << p2.getBookSize() << " cards." << endl;
  log << "So the winner is: ";
  if (p1.getBookSize() < p2.getBookSize()) {
    log << "Player 2!";
  }
  if (p1.getBookSize() > p2.getBookSize()) {
    log << "Player 1!";
  }
  if (p1.getBookSize() == p2.getBookSize()) {
    log << "Nobody! It's a tie.";
  }

  return 0;
}

// Game rules and edge cases:
// If you start your turn without any cards in your hand, your entire turn is just drawing a card.