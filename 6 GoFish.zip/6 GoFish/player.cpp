// Created by Saagar Pateder on 4/9/2019.
// FILE: player.cpp
// Originally written by Roger Priebe
// 1/22/08 (revised 9/2/08)
// This class represents a player in a card game that takes "tricks"
// The "Books" represent a container for holding tricks

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstdlib>
#include <ctime>
#include "card.h"
#include "player.h"

using namespace std;

  // Default name is ""
  Player::Player() {
    myName = "";
    unsigned int currentTime = (unsigned) time(0);
    srand(currentTime);
  }

  // adds a card to the hand
  void Player::addCard(Card c) {
    myHand.push_back(c);
  }

  // books two cards by removing them from the player's hand and adding them to the player's book
  void Player::bookCards(Card c1, Card c2) {
    myBook.push_back(c1);
    myBook.push_back(c2);
    removeCardFromHand(c1);
    removeCardFromHand(c2);
  }

  // checks a players hand for a pair
  // If a pair is found, it returns true and populates the two variables with the cards tha make the pair.
  bool Player::checkHandForBook(Card &c1, Card &c2) {
    for (int i = 0; i < myHand.size(); i++) {
      for (int j = i+1; j < myHand.size(); j++) {
        if (myHand.at(i).getRank() == myHand.at(j).getRank()) {
          c1 = myHand.at(i);
          c2 = myHand.at(j);
          return true;
        }
      }
    }
    return false;
  }

  // Does the player have a card with the same rank as c in her hand?
  bool Player::rankInHand(Card c) const {
    for (int i = 0; i < myHand.size(); i++) {
      if (myHand.at(i).getRank() == c.getRank()) {return true;}
    }
    return false;
  }

  // uses some strategy to choose one card from the player's
  // hand so they can say "Do you have a 4?"
  // My strategy: always ask about the last card in the hand
  // Theory is that it'll be the most recently drawn
  Card Player::chooseCardFromHand() const {
    int index = (rand() % (getHandSize()));
    return myHand.at(index);
  }

  // Does the player have the card c in her hand?
  bool Player::cardInHand(Card c) const {
    for (int i = 0; i < myHand.size(); i++) {
      if (myHand.at(i) == c) {return true;}
    }
    return false;
  }

  // Remove the card c from the hand and return it to the caller
  Card Player::removeCardFromHand(Card c) {
    for (int i = 0; i < myHand.size(); i++) {
      if (myHand.at(i) == c) {
        myHand.erase(myHand.begin()+i);
        return c;
      }
    }
    cout << "ERROR: CARD NOT FOUND in removeCardFromHand()";
  }

  string Player::showHand() const {
    string returnable = "";
    for (int i = 0; i < getHandSize(); i++) {
      returnable += myHand.at(i).toString();// myHand.at(i).toString();
      returnable += " ";
    }
    return returnable;
  }

  string Player::showBooks() const {
    string returnable = "";
    for (int i = 0; i < getBookSize(); i++) {
      returnable += myBook.at(i).toString();
      returnable += " ";
    }
    return returnable;
  }

  int Player::getHandSize() const {
    return myHand.size();
  }

  int Player::getBookSize() const {
    return myBook.size();
  }

  // TODO testing
  Card Player::scanForRank(int rank) {
    Card temp1 = Card(rank, Card::spades);
    if (cardInHand(temp1)) {return temp1;}
    Card temp2 = Card(rank, Card::hearts);
    if (cardInHand(temp2)) {return temp2;}
    Card temp3 = Card(rank, Card::diamonds);
    if (cardInHand(temp3)) {return temp3;}
    Card temp4 = Card(rank, Card::clubs);
    if (cardInHand(temp4)) {return temp4;}
    cout << "ERROR: Found no card!" << endl;
  }
