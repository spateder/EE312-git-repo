// Created by Saagar Pateder on 4/9/2019.
// FILE: deck.cpp
// Originally written by Owen Astrachan and Roger Priebe
// this class represents a deck of cards
// When a Deck is constructed, it contains 52 cards
// in a "regular" order (aces, twos, threes, ... , kings)
// Shuffling a deck makes it consist of 52 cards in a random order
// dealCard() returns a card from the deck...
// ...and decreases the number of cards in the deck (returned by size())
// The idea is that after shuffling, calling dealCard() 52 times
// returns each card in the deck after shuffling.
// Calling shuffle again replenishes the deck with 52 cards.

#include "deck.h"
#include "card.h"
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

Deck::Deck() {
  myIndex = 0;

  // Generate the cards in the deck
  for (int i = 1; i <= 13; i++){
    for (int _suit = Card::spades; _suit <= Card::clubs; _suit++) {
      myCards[myIndex] = Card(i, (Card::Suit) _suit);
      myIndex++;
    }
  }

  myIndex = 0;
  unsigned int currentTime = (unsigned) time(0);
  srand(currentTime);
}

void Deck::shuffle() {

  // for each card in the deck...
  for (int i = 0; i <= SIZE-1; i++) {
    // pick an index between (inclusive) the card and (inclusive) the end of the deck
    int swapIndex = i + (rand() % (SIZE-i));
    // and swap those cards
    Card temp = Card();
    temp = myCards[i];
    myCards[i] = myCards[swapIndex];
    myCards[swapIndex] = temp;
  }

  myIndex = 0;
}

Card Deck::dealCard() {
  if(myIndex >= 52) {cout << "ERROR: Tried to deal card #53" << endl;}
  myIndex++;
  return myCards[myIndex - 1];
}

void Deck::print() {
  cout << "myIndex: " << myIndex << endl;
  for (int i = 0; i <= 51; i++) {
    cout << myCards[i].toString();
    cout << " ";
  }
  cout << endl;
}

int Deck::size() const {
  return SIZE - myIndex;
}